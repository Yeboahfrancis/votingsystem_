<?php
	$conn = new mysqli('localhost', 'root', '', 'fire');
	
	if(!$conn){
		die("Error: Failed to connect to database");
	}
?>	